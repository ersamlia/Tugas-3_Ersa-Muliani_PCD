﻿**LAPORAN** 

**PENGERJAAN TUGAS**

**PEMROSESAN CITRA DIGITAL**

**(ABKC6306)**


**“ Detail Halftoning : Patterning & Detailing ”**


![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.001.png)


**Oleh:**

Ersa Muliani  (2310131220001)


**Dosen Pengampu :**

Dr. Harja Santana Purba, M.Kom

Novan Alkaf Bahraini Saputra, S.Kom., M.T



**PROGRAM STUDI PENDIDIKAN KOMPUTER**

**FAKULTAS KEGURUAN DAN ILMU PENDIDIKAN**

**UNIVERSITAS LAMBUNG MANGKURAT**

**TAHUN 2024**
# <a name="_toc178186812"></a>**DAFTAR ISI** 
#
[DAFTAR ISI	ii](#_toc178186812)

[PENDAHULUAN	1](#_toc178186813)

[HASIL ANALISIS DAN PEMBAHASAN	2](#_toc178186814)

[A.	Pengertian Halftoning	2](#_toc178186815)

[B.	Teknik Halftoning	2](#_toc178186816)

[1.	Patterning	2](#_toc178186817)

[2.	Detailing	6](#_toc178186819)

[3.	Perbedaan Teknik Patterning dan Detailing	8](#_toc178186820)

[DAFTAR PUSTAKA	9](#_toc178186821)




#
2

# <a name="_toc178186813"></a>**PENDAHULUAN**

Halftoning adalah teknik penting dalam pengolahan citra digital yang mengubah citra kontinu menjadi array titik-titik kecil yang, ketika dilihat oleh mata manusia, memberikan kesan bahwa citra tersebut memiliki gradasi warna yang halus. Halftoning sangat penting dalam berbagai aplikasi, terutama dalam pencetakan dan tampilan citra pada perangkat yang memiliki keterbatasan dalam menampilkan gradasi warna.

Salah satu metode halftoning yang umum digunakan adalah *patterning*. Teknik patterning menggunakan pola titik-titik yang telah ditentukan sebelumnya untuk menciptakan ilusi gradasi warna. Pola ini diulang-ulang di seluruh gambar, sehingga area yang lebih gelap akan memiliki pola titik-titik yang lebih rapat, sedangkan area yang lebih terang akan memiliki pola titik-titik yang lebih jarang. Contoh pola yang sering digunakan dalam teknik patterning adalah Bayer matrix. Teknik ini sederhana dan cepat, namun bisa menghasilkan pola yang terlihat pada gambar akhir.

Di sisi lain***,** detailing* adalah teknik halftoning yang fokus pada peningkatan kualitas gambar dengan memperhatikan detail-detail penting seperti tepi objek atau tekstur halus. Teknik detailing melibatkan penyesuaian titik-titik di area yang memiliki detail penting untuk mempertahankan atau meningkatkan detail tersebut. Biasanya, teknik ini menggunakan ambang batas untuk menentukan apakah piksel akan menjadi hitam atau putih. Dengan fokus pada detail, gambar yang dihasilkan akan memiliki kualitas visual yang lebih baik dan terlihat lebih tajam serta realistis.

Kedua teknik ini, memiliki kelebihan dan kekurangan masing-masing. Patterning lebih sederhana dan cepat, namun bisa menghasilkan pola yang terlihat pada gambar. Sementara itu, detailing lebih kompleks dan memerlukan penyesuaian yang lebih teliti, namun menghasilkan gambar dengan kualitas visual yang lebih baik. Pemilihan teknik yang tepat tergantung pada kebutuhan spesifik dari aplikasi dan perangkat yang digunakan. Dengan memahami perbedaan dan keunggulan masing-masing teknik, kita dapat memilih metode halftoning yang paling sesuai untuk menghasilkan gambar dengan kualitas terbaik.
# <a name="_toc178186814"></a>**HASIL ANALISIS DAN PEMBAHASAN** 

1. ## <a name="_toc178186815"></a>**Pengertian Halftoning**
   Halftoning adalah teknik yang digunakan untuk menciptakan ilusi gradasi warna pada gambar yang sebenarnya hanya terdiri dari titik-titik hitam dan putih. Ini sangat berguna dalam pencetakan dan tampilan gambar pada perangkat yang hanya bisa menampilkan dua warna. Teknik ini mengubah citra menjadi array titik-titik kecil yang ketika dilihat oleh mata manusia, memberikan kesan bahwa citra tersebut memiliki gradasi warna yang halus.
1. ## <a name="_toc178186816"></a>**Teknik Halftoning** 
1. ### <a name="_toc178186817"></a>Patterning
   Patterning adalah teknik halftoning yang menggunakan pola titik-titik yang telah ditentukan sebelumnya untuk menciptakan ilusi gradasi warna. Pola ini diulang-ulang di seluruh gambar untuk menghasilkan efek gradasi. Misalnya, untuk menciptakan area yang tampak lebih gelap, pola titik-titik akan lebih rapat, sedangkan untuk area yang lebih terang, pola titik-titik akan lebih jarang.

   Contoh penghitungannya :

- Pada Binary font 3x3 dengan skala nilai menggunakan 8-bit grayscale yaitu 0 hingga 255, teknik ini menggunakan sepuluh buah pola yang di setiap polanya ada jumlah 26 rentang. Penghitungan rentang di ambil dari jumlah skala nilai yaitu 256/10 pola warna sehingga menghasilkan 26 jumlah rentang pada setiap polanya. Maka dihasilkan gambar dengan pola sebagai berikut :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.002.png)       ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.003.png)       ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.004.png)

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.005.png)          ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.006.png)       ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.007.png)

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.008.png)        ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.009.png)         ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.010.png)

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.011.png)

  Dengan rentang nilai sebagai berikut :

  ***Pola 0*** : 0 – 25			Pola 5 : 130 – 155

  Pola 1 : 26 – 51		Pola 6 : 156 – 181 

  Pola 2 : 52 – 77		Pola 7 : 182 – 207

  Pola 3 : 78 – 103		Pola 8 : 208 – 233

  Pola 4 : 104 – 129 		Pola 9 : 234 – 255

  Setiap 1 pixel jika diubah menjadi binary font 3x3, maka gambar pola akan 3x lipat lebih besar. 




- ***Contoh soal sederhana*** :

  Gambarkan pola dari matriks berikut menggunakan Algoritma Patterning binary font 3x3

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.012.png)     

  Dari matriks di atas, maka diperoleh dengan nomor pola:

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.013.png)

  Karena matriks berukuran 2x2 di ubah dengan binary font 3x3, maka setiap satu kotak akan berubah menjadi 3 buah kotak. Sehingga matriks berubah ukurannya menjadi 6x6. Dengan Gambar pola sebagai berikut :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.014.png)




- Kode Program :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.015.png)

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.016.png)

  Hasil Output :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.017.png)



1. ### <a name="_toc178186818"></a><a name="_toc178186819"></a>Detailing
   Detailing adalah teknik dalam halftoning yang fokus pada peningkatan kualitas gambar dengan memperhatikan detail-detail penting. Tujuannya adalah membuat gambar terlihat lebih tajam dan realistis. 

   Contoh Penghitungannya :

- Angka pixel di grayscale dibandingkan dengan matriks dithern nya.

  Jika nilai > threshold, maka white (1)

  Jika nilai <= threshold, maka black (0)

- ***Contoh soal sederhana*** :

  Coba buatkan gambar pola dari matriks dibawah ini dengan teknik Detailing.

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.018.png)

  Dengan matriks ditern / threshold :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.019.png)

  Maka, ubah matriks dengan membandingkan angka dengan menyesuaikan / mencocokkan angka sesuai dengan tempat angkanya, sehingga di peroleh :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.020.png)

  Maka di peroleh gambar pola :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.021.png)

- Kode Program :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.022.png)![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.023.png)

  Output :

  ![](Aspose.Words.989edc60-47a9-467c-a7b7-2169bb4ad166.024.png)

1. ### <a name="_toc178186820"></a>Perbedaan Teknik Patterning dan Detailing

   |Patterning|Detailing|
   | :-: | :-: |
   |Menggunakan pola titik-titik yang telah ditentukan sebelumnya (seperti Bayer matrix) untuk menentukan apakah piksel akan menjadi hitam atau putih.|Menggunakan ambang batas sederhana untuk menentukan apakah piksel akan menjadi hitam atau putih, dengan fokus pada detail gambar.|



# <a name="_toc178186821"></a>**DAFTAR PUSTAKA**
#
al, P. e. (1994). Digital Halftoning Techniques for Printing. *S&T’s 47th Annual Conference, Rochester*, 1-5.

Septiana, L. (2013). Halftoning Citra Menggunakan Metode Ordered Dithering. *Jurnal Teknik dan Ilmu Komputer*.



